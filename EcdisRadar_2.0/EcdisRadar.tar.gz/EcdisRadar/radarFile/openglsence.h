#ifndef OPENGLSENCE_H
#define OPENGLSENCE_H

#include <QGraphicsScene>
#include <QGroupBox>




class OpenGLSence : public QGraphicsScene
{
    Q_OBJECT
public:
    explicit OpenGLSence(QObject *parent = 0);

protected:

private:


};

#endif // OPENGLSENCE_H
