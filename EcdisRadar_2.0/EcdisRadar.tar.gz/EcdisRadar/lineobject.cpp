#include "lineobject.h"

LineObject::LineObject():object_label(0), record_id(0), group(0), feature_id(0), feature_subid(0)
{
}

LineObject::~LineObject()
{
}
