#ifndef SOUNDOBJECT_H
#define SOUNDOBJECT_H


#include <QVector>

#include "s57/s57.h"



class SoundObject
{
public:
    SoundObject();
    ~SoundObject();

    //属性信息
    int object_label;  //物标类型
    int record_id;  //物标唯一编码
    int group;
    int prim;

    int feature_id;
    int feature_subid;

    std::string name;  //物标名称

    std::vector<attf_t> attfs;   //属性字段
    std::vector<attf_t> natfs;    //国家属性字段
    std::vector<ffpt_t> ffpts;    //特征记录到特征物标指针
    std::vector<fspt_t> fspts;    //特征字段到空间字段指针
    //空间属性
    std::vector<attv_t> attvs;
    std::vector<sg3d_t> sg3ds;

    //符号化相关   CS(SOUNDG02) OTHER 33010 OVERRADAR 6
   // QStringList symInstruction;    //符号化指令,只保存了符号名字

};

#endif // SOUNDOBJECT_H
