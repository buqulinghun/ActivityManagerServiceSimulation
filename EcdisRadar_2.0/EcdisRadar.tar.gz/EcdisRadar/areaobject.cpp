#include "areaobject.h"

AreaObject::AreaObject():object_label(0), record_id(0), group(0), feature_id(0), feature_subid(0)
{
}

AreaObject::~AreaObject()
{
}
