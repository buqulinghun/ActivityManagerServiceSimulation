#include "soundobject.h"
#include "configuration.h"

SoundObject::SoundObject():object_label(0), record_id(0), group(0), feature_id(0), feature_subid(0)
{

}

SoundObject::~SoundObject()
{

}
