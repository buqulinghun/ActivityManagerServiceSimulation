/********************************************************************
 *日期: 2016-01-12
 *作者: 王名孝
 *作用: 存储点物标结构
 *修改:
 ********************************************************************/

#include "pointobject.h"

/**
 * Constructor
 */
PointObject::PointObject():index(-1), object_label(0), record_id(0), group(0), feature_id(0), feature_subid(0)
{

}

/**
 * Destructor
 */
PointObject::~PointObject()
{
}
