#include "waypoint.h"

Waypoint::Waypoint()
{
}

Waypoint::~Waypoint()
{
}
